#include <iostream>
#include <stdio.h>

using namespace std;

class Matrix{
	int **massiv;
	int mas_i, mas_j;
public:
	void MakeMatrix();
	void NullElement();
	void ShowMatrix();
	void MakeNullElements();
	void SearchMin();
	void SearchMax();
	void SearchModMax();
	void MakeMiddle();
	void DeleteMatrix();
	void Reverse();
};

void Matrix::MakeMatrix(){
	error:cout<<"Enter size stroke of Matrix"<<endl;
	cin>>mas_i;
	cout<<"Enter size colomn of Matrix"<<endl;
	cin>>mas_j;
	if(mas_i<0||mas_j<0)
	{
		cout<<"ERROR!!!!!"<<endl;
		goto error;
	}
	else
	{
		cout<<"Enter element of massiv"<<endl;
		massiv=new int*[mas_i];
		for(int i=0;i<mas_i;i++)
			massiv[i]=new int[mas_j];
		for(int i=0;i<mas_i;i++)
			for(int j=0;j<mas_j;j++)
				cin>>massiv[i][j];
	}
}

void Matrix::ShowMatrix(){
	cout<<endl;
	for(int i=0;i<mas_i;i++)
	{
		for(int j=0;j<mas_j;j++)
			cout<<massiv[i][j]<<"  ";
		cout<<endl;
	}
}

void Matrix::DeleteMatrix(){
	for(int i=0;i<mas_i;i++)
		delete []massiv[i];
}

void Matrix::NullElement(){
	int k,l;
	cout<<"Enter stroke"<<endl;
	cin>>k;
	cout<<"Enter colomn"<<endl;
	cin>>l;
	for(int i=0;i<mas_i;i++)
		for(int j=0;j<mas_j;j++)
			if(k==i||l==j)
				massiv[i][j]=0;
}

void Matrix::SearchMin(){
	int min=0,min_i,min_j,MinInMaxI,MinInMaxJ;
	for(int i=0;i<mas_i;i++)
	{
		for(int j=0;j<mas_j;j++)
			if(massiv[i][j]>0)
			{
				min=massiv[i][j];
				min_i=i;
				min_j=j;
				goto next;
			}
	}
next:for(min_i;min_i<mas_i;min_i++)
		 for(min_j;min_j<mas_j;min_j++)
			 if(massiv[min_i][min_j]>0&&massiv[min_i][min_j]<min)
			 {
				 min=massiv[min_i][min_j];
				 MinInMaxI=min_i;
				 MinInMaxJ=min_j;
			 }
			 int temp;
int max=0,max_i,max_j,MaxInMinI,MaxInMinJ;
	for(int i=0;i<mas_i;i++)
	{
		for(int j=0;j<mas_j;j++)
			if(massiv[i][j]<0)
			{
				max=massiv[i][j];
				max_i=i;
				max_j=j;
				break;
			}
	}
next2:for(int max_i;max_i<mas_i;max_i++)
	  {
		 for(int max_j;max_j<mas_j;max_j++)
			 if(massiv[max_i][max_j]<0&&massiv[max_i][max_j]>max)
			 {
				 max=massiv[max_i][max_j];
				 MaxInMinI=max_i;
				 MaxInMinJ=max_j;
			 }
	  }
			 temp=massiv[MaxInMinI][MaxInMinJ];
			 massiv[MaxInMinI][MaxInMinJ]=massiv[MinInMaxI][MinInMaxJ];
			 massiv[MinInMaxI][MinInMaxJ]=temp;
}

void Matrix::MakeMiddle(){
	int max_module=abs(massiv[0][0]),index_max,middleCount,maxI,maxJ;
	for(int i=0;i<mas_i;i++)
		for(int j=1;j<mas_j;i++)
		{
			if(abs(massiv[i][j])>max_module)
			{
				max_module=abs(massiv[i][j]);
				index_max=i;
				maxI=i;
				maxJ=j;
			}
		}
		for(int i=0;i<mas_i;i++)
			if(i==index_max)
				for(int j=0;j<mas_j;j++)
					middleCount+=massiv[i][j];
		middleCount/=mas_j;
		massiv[maxI][maxJ]=middleCount;
}

int main(){
	Matrix MyMatrix;
	MyMatrix.MakeMatrix();
	MyMatrix.ShowMatrix();
	MyMatrix.NullElement();
	MyMatrix.ShowMatrix();
	MyMatrix.SearchMin();
	MyMatrix.ShowMatrix();
	MyMatrix.MakeMiddle();
	MyMatrix.ShowMatrix();
	MyMatrix.DeleteMatrix();
system("pause");
}